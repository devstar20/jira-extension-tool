/* global chrome */
var popupWindow = window.open(
  chrome.extension.getURL('popup.html'),
  'Jira Worklog Tool',
  'width=1200, height=1100'
)
popupWindow.focus()
window.close()
