var chrome = window.chrome || {}
var JiraHelper = window.JiraHelper || {}
var data = {
    start: false,
    endtime:""
}

function isEmpty(obj) {
  for(var key in obj){
    if(obj.hasOwnProperty(key))
      return false
  }
  return true
}

// Saves options to chrome.storage
function saveOptions (options, flag) {
  // make sure to not save user password, as chrome storage is not encrypted (https://developer.chrome.com/apps/storage#using-sync).
  options.password = ''

  chrome.storage.sync.set(
    {
      workOptions: options
    },
    function () {
      // Update status to let user know options were saved.
     
      setTimeout(function () {
          switch(flag){
              case 0:
                 
                  document.getElementById('workDaystart').setAttribute('style', 'display:none')
                  document.getElementById('setDayEnd').setAttribute('style', 'display:block')
                  document.getElementById('getWorklogButton').setAttribute('style', 'display:none')
                  document.getElementById('btnExtendWork').setAttribute('style', 'display:none')
                  var time = new Date()
                  var currentTime = time.getHours() + ':' + time.getMinutes()
                  var hours = ''
                  var minutes = ''
                  if(time.getHours() <  10){
                    hours = '0' + time.getHours()
                  }else{
                    hours = time.getHours()
                  }
                  if(time.getMinutes() <  10){
                    minutes = '0' + time.getMinutes()
                  }else{
                    minutes = time.getMinutes()
                  }
                  var currentTime = hours + ':' + minutes
                  document.getElementById('workEndTime').value = currentTime
                  break
              case 1:
                  document.getElementById('setDayEnd').setAttribute('style', 'display:none')
                  document.getElementById('btnExtendWork').setAttribute('style', 'display:none')
                  document.getElementById('workDayEnd').setAttribute('style', 'display:block')
                  alert("Your Work Day has Started!")
                  break
              case 2:
                  alert('Your Work Day Ended!')
                  document.getElementById('workDaystart').setAttribute('style', 'display:block')
                  document.getElementById('setDayEnd').setAttribute('style', 'display:none')
                  document.getElementById('workDayEnd').setAttribute('style', 'display:none')
                  document.getElementById('getWorklogButton').setAttribute('style', 'display:block')
                  document.getElementById('btnExtendWork').setAttribute('style', 'display:none')
                  break
              default: break
          }
      }, 750)
    }
  )
}

// Restores options state using the preferences
// stored in chrome.storage.
function restoreOptions () {
  chrome.storage.sync.get(
    {
        workOptions: {}
    },
    function (items) {
        console.log("work options", items);
        if(isEmpty(items.workOptions)){
          return;
        }
        restoreOptionsToSet(items.workOptions)
      //restoreOptionsToInput(items.workOptions)
    }
  )
}

//{endtime: "", password: "", start: true}
function restoreOptionsToSet(options) {
    data = options

    if(data.start == false){
        document.getElementById('workDaystart').setAttribute('style', 'display:block')
        document.getElementById('setDayEnd').setAttribute('style', 'display:none')
        document.getElementById('workDayEnd').setAttribute('style', 'display:none')
        document.getElementById('getWorklogButton').setAttribute('style', 'display:none')
        document.getElementById('btnExtendWork').setAttribute('style', 'display:none')
        
    }else{
        if(data.endtime == ""){
            
            document.getElementById('workDaystart').setAttribute('style', 'display:none')
            document.getElementById('setDayEnd').setAttribute('style', 'display:block')
            document.getElementById('getWorklogButton').setAttribute('style', 'display:none')
            document.getElementById('btnExtendWork').setAttribute('style', 'display:none')
            var time = new Date()
            var currentTime = time.getHours() + ':' + time.getMinutes()
            var hours = ''
            var minutes = ''
            if(time.getHours() <  10){
              hours = '0' + time.getHours()
            }else{
              hours = time.getHours()
            }
            if(time.getMinutes() <  10){
              minutes = '0' + time.minutes()
            }else{
              minutes = time.getMinutes()
            }
            var currentTime = hours + ':' + minutes

            document.getElementById('workEndTime').value = currentTime
            workCheck(200000)
        }else{
            document.getElementById('workDaystart').setAttribute('style', 'display:none')
            document.getElementById('workDayEnd').setAttribute('style', 'display:block')
            document.getElementById('setDayEnd').setAttribute('style', 'display:none')
            document.getElementById('getWorklogButton').setAttribute('style', 'display:none')
            document.getElementById('btnExtendWork').setAttribute('style', 'display:none')
            workCheck(2000)
        }
            
    }
    return
}

function workCheck(eventTime){
  if(data.start == false)return
  console.log("workCheck")
  setTimeout(()=>{
    var time = new Date()
    
    if(data.endtime == ""){
      console.log("empty time log started")
      alert("You didn't set the workend time!")
      workCheck(200000)
    } else {
      var timeParse = data.endtime.split(':')
      if(time.getHours() >= timeParse[0] && time.getMinutes() >= timeParse[1]){
        //display the extend button
        document.getElementById('btnExtendWork').setAttribute('style', 'display:initial')
        alert("Your worklog has been ended!")
        return
      }else{
        workCheck(2000)
      }
    }
  }, eventTime)
}

document.addEventListener('DOMContentLoaded', () => {
  restoreOptions()
  
  document.getElementById('btnStartWork').addEventListener('click', () => {
    data.start = true
    saveOptions(data, 0)
    //call timer function
    workCheck(200000)
  })

  document.getElementById('btnEndWork').addEventListener('click', () => {
      data.start = false
      data.endtime = ""
      saveOptions(data, 2)
  })

  document.getElementById('setEndTime').addEventListener('click', () => {
      data.endtime = document.getElementById('workEndTime').value
      saveOptions(data, 1)
      workCheck(2000)
  })

  document.getElementById('btnExtendWork').addEventListener('click', () => {
    document.getElementById('setDayEnd').setAttribute('style', 'display:block')
    document.getElementById('workEndTime').value = data.endtime
    document.getElementById('btnExtendWork').setAttribute('style', 'display:none')
  })
})
