function restoreOptions () {
    chrome.storage.sync.get(
      {
        workOptions: {}
      },
      function (items) {
        console.log("jira options in content js", items);
      //restoreOptionsToInput(items.workOptions)
    }
    )
  }

  console.log("hello world12312123");

  window.onload = (event) => {
      console.log("hello world onload");
      restoreOptions();
  }
  